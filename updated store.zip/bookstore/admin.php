<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['username'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "OnlineStore";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define the directory to store covers
$photo_dir = "photos/";
if (!is_dir($photo_dir)) {
    mkdir($photo_dir, 0777, true); // Create the directory if it doesn't exist
}

// Handle add product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $product_title = $_POST['product_title'];
    $product_price = $_POST['product_price'];
    $discount_price = !empty($_POST['discount_price']) ? $_POST['discount_price'] : NULL;  // If empty, set as NULL
    $cover_name = NULL;
    $description = $_POST['description'];



// Handle cover upload or download
if (isset($_FILES['product_cover']) && $_FILES['product_cover']['error'] === UPLOAD_ERR_OK) {
    $cover_tmp_name = $_FILES['product_cover']['tmp_name'];
    $cover_name = basename($_FILES['product_cover']['name']);
    $target_file = $photo_dir . $cover_name;

    if (!move_uploaded_file($cover_tmp_name, $target_file)) {
        die("Failed to upload cover.");
    }
} elseif (!empty($_POST['cover_link'])) {
    $cover_url = $_POST['cover_link'];

    // Fetch cover data
    $cover_data = file_get_contents($cover_url);
    if ($cover_data === false) {
        die("Failed to download cover from URL.");
    }

// Create a temporary file to analyze the cover type
$temp_cover = tempnam(sys_get_temp_dir(), 'img');
file_put_contents($temp_cover, $cover_data);

// Get MIME type of the cover
$cover_info = getimagesize($temp_cover);
if ($cover_info === false) {
    die("Failed to determine the cover type.");
}

// Map MIME types to file extensions
$mime_to_extension = [
    'cover/jpeg' => '.jpg',
    'cover/png' => '.png',
    'cover/gif' => '.gif',
    'cover/webp' => '.webp',
];

$extension = isset($mime_to_extension[$cover_info['mime']]) ? $mime_to_extension[$cover_info['mime']] : '.jpg';

// Construct the local filename with the correct extension
$cover_name = uniqid('img_', true) . $extension; // Use a unique name to avoid collisions
$target_file = $photo_dir . $cover_name;

// Save the cover locally
if (!file_put_contents($target_file, $cover_data)) {
    die("Failed to save the cover locally.");
}
}

    // Validate inputs
    if (empty($product_title) || !is_numeric($product_price)) {
        echo "<p>Invalid input data. Please provide a valid product title and price.</p>";
    } else {
        // Insert product with description, cover link, and NULL or discount price
        $stmt = $conn->prepare("INSERT INTO products (title, price, discount_price, cover, description) VALUES (?, ?, ?, ?, ?)");
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("sdsss", $product_title, $product_price, $discount_price, $target_file, $description);

        if ($stmt->execute()) {
            echo "<p>Product added successfully.</p>";
        } else {
            echo "<p>Error: " . $stmt->error . "</p>";
        }
        $stmt->close();
    }
}

// Handle delete product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
    $product_id = $_POST['product_id'];

    // Validate input
    if (empty($product_id) || !is_numeric($product_id)) {
        echo "<p>Invalid product ID.</p>";
    } else {
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("i", $product_id);

        if ($stmt->execute()) {
            echo "<p>Product deleted successfully.</p>";
        } else {
            echo "<p>Error: " . $stmt->error . "</p>";
        }
        $stmt->close();
    }
}

// Handle update product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_product'])) {
    $product_id = $_POST['product_id'];
    $product_title = $_POST['product_title'];
    $product_price = $_POST['product_price'];
    $discount_price = ($_POST['discount_price'] === '0' || $_POST['discount_price'] === '') ? NULL : $_POST['discount_price'];  // Handle discount price as NULL when empty or 0
    $cover_link = $_POST['cover_link'];
    $description = $_POST['description'];

    // Validate inputs
    if (
        empty($product_id) || empty($product_title) || 
        !is_numeric($product_id) || !is_numeric($product_price) || 
        (!empty($discount_price) && !is_numeric($discount_price))
    ) {
        echo "<p>Invalid input data. Please check all fields.</p>";
    } else {
        // Update product with cover link and description, handle discount price as NULL
        $stmt = $conn->prepare("UPDATE products SET title = ?, price = ?, discount_price = ?, cover = ?, description = ? WHERE id = ?");
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("sdsssi", $product_title, $product_price, $discount_price, $cover_link, $description, $product_id);

        if ($stmt->execute()) {
            echo "<p>Product updated successfully.</p>";
        } else {
            echo "<p>Error: " . $stmt->error . "</p>";
        }
        $stmt->close();
    }
}

// Fetch all products
$result = $conn->query("SELECT * FROM products");
if (!$result) {
    die("Query failed: " . $conn->error);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Interface</title>
</head>
<body>
    <h1>Welcome, Admin</h1>

    <h2>Add Product</h2>
    <form method="post">
        <label for="product_title">Product Title:</label><br>
        <input type="text" id="product_title" name="product_title" required><br>
        <label for="product_price">Product Price:</label><br>
        <input type="number" step="0.01" id="product_price" name="product_price" required><br>
        <label for="discount_price">Discount Price:</label><br>
        <input type="number" step="0.01" id="discount_price" name="discount_price" placeholder="Optional"><br>
        <label for="cover_link">Product Cover (cover URL):</label><br>
        <input type="text" id="cover_link" name="cover_link" required placeholder="e.g. https://example.com/cover.jpg"><br>
        <label for="description">Description:</label><br>
        <textarea id="description" name="description" rows="4" cols="50" required></textarea><br>
        <button type="submit" name="add_product">Add Product</button>
    </form>

    <h2>Existing Products</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Price</th>
            <th>Discount Price</th>
            <th>Cover</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?php echo htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?php echo htmlspecialchars($row['price'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?php echo (is_null($row['discount_price']) ? 'N/A' : htmlspecialchars($row['discount_price'], ENT_QUOTES, 'UTF-8')); ?></td>
                <td>
                    <?php if (!empty($row['cover'])) { ?>
                        <img src="<?php echo htmlspecialchars($row['cover'], ENT_QUOTES, 'UTF-8'); ?>" alt="Cover cover" style="max-width: 100px;">
                    <?php } else { ?>
                        No cover uploaded
                    <?php } ?>
                </td>
                <td><?php echo nl2br(htmlspecialchars($row['description'], ENT_QUOTES, 'UTF-8')); ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8'); ?>">
                        <button type="submit" name="delete_product">Delete</button>
                    </form>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8'); ?>">
                        <input type="text" name="product_title" value="<?php echo htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8'); ?>" required>
                        <input type="number" step="0.01" name="product_price" value="<?php echo htmlspecialchars($row['price'], ENT_QUOTES, 'UTF-8'); ?>" required>
                        <input type="number" step="0.01" name="discount_price" value="<?php echo htmlspecialchars($row['discount_price'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="Discount Price">
                        <input type="text" name="cover_link" value="<?php echo htmlspecialchars($row['cover'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="cover URL" required>
                        <textarea name="description" rows="4" cols="50"><?php echo htmlspecialchars($row['description'], ENT_QUOTES, 'UTF-8'); ?></textarea>
                        <button type="submit" name="update_product">Update</button>
                    </form>
                </td>
            </tr>
        <?php } ?>
    </table>

    <p><a href="logout.php">Logout</a></p>
</body>
</html>

<?php
$conn->close();
?>
